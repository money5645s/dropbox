-- 후원 대상 플레이어를 같은 월드에 있는 다른 접속자 근처로 순간이동시킵니다.

local TELEPORT_HEIGHT_OFFSET = 120.0

local function isValidObject(object)
    return object ~= nil and object:IsValid()
end

local function copyLocation(location)
    return {
        X = tonumber(location.X) or 0.0,
        Y = tonumber(location.Y) or 0.0,
        Z = (tonumber(location.Z) or 0.0) + TELEPORT_HEIGHT_OFFSET,
    }
end

local function copyRotation(rotation)
    return {
        Pitch = tonumber(rotation.Pitch) or 0.0,
        Yaw = tonumber(rotation.Yaw) or 0.0,
        Roll = tonumber(rotation.Roll) or 0.0,
    }
end

local function findRandomDestination(sourcePlayerUid)
    local _, sourceController = findPlayerStateByUid(sourcePlayerUid)
    if not isValidObject(sourceController) then
        return nil, "대상 플레이어 컨트롤러를 찾지 못했습니다."
    end

    local sourcePawn = sourceController.Pawn
    if not isValidObject(sourcePawn) then
        return nil, "대상 플레이어 캐릭터를 찾지 못했습니다."
    end

    local sourceWorld = sourcePawn:GetWorld()
    if not isValidObject(sourceWorld) then
        return nil, "대상 플레이어의 월드를 찾지 못했습니다."
    end

    local sourceWorldName = sourceWorld:GetFullName()
    local sourceUidA = sourcePlayerUid.A
    local candidates = {}

    for _, playerController in pairs(PalPlayerControllers:getServerPlayers() or {}) do
        if isValidObject(playerController) then
            local playerState = playerController:GetPalPlayerState()
            local pawn = playerController.Pawn

            if isValidObject(playerState)
                and isValidObject(pawn)
                and playerState.PlayerUId.A ~= sourceUidA then
                local playerWorld = pawn:GetWorld()
                if isValidObject(playerWorld)
                    and playerWorld:GetFullName() == sourceWorldName then
                    table.insert(candidates, {
                        name = playerState.PlayerNamePrivate:ToString(),
                        pawn = pawn,
                    })
                end
            end
        end
    end

    if #candidates == 0 then
        return nil, "같은 월드에 순간이동할 다른 접속 플레이어가 없습니다."
    end

    return sourcePawn, candidates[math.random(1, #candidates)]
end

local function teleportToRandomPlayer(sourcePlayerUid)
    local sourcePawn, destinationOrErr = findRandomDestination(sourcePlayerUid)
    if sourcePawn == nil then
        return false, destinationOrErr
    end

    local destinationPlayer = destinationOrErr
    -- 위치와 회전값을 즉시 Lua 테이블로 복사해 UFunction 반환 구조체 참조를 보관하지 않습니다.
    local location = copyLocation(destinationPlayer.pawn:GetActorLocation())
    local rotation = copyRotation(destinationPlayer.pawn:GetActorRotation())

    -- AActor::TeleportTo(FVector, FRotator, bIsATest, bNoCheck)
    -- 충돌 검사를 유지해 지형 안쪽으로 강제 이동하는 것을 막습니다.
    local teleported = sourcePawn:TeleportTo(location, rotation, false, false)
    if teleported == false then
        return false, "순간이동 위치가 막혀 이동하지 못했습니다."
    end

    return true, destinationPlayer.name
end

return function(context)
    local calledOk, teleported, resultOrErr = xpcall(function()
        return teleportToRandomPlayer(context.playerUid)
    end, debug.traceback)

    if not calledOk or not teleported then
        local errorMessage = calledOk and resultOrErr or teleported
        context.log("랜덤 텔포 이벤트 실패: " .. tostring(context.playerName)
            .. " / " .. tostring(errorMessage))
        return false, tostring(errorMessage)
    end

    context.sendSystemToPlayer(
        context.playerUid,
        "[후원] " .. tostring(resultOrErr) .. " 님 근처로 순간이동했습니다!"
    )
    context.log("랜덤 텔포 이벤트 완료: " .. tostring(context.playerName)
        .. " → " .. tostring(resultOrErr))
    return true, "랜덤 텔포 이벤트를 적용했습니다."
end
