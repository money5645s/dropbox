require("Pal")

-- 처리 중인 후원은 별도 파일에 보관합니다.
-- 서버가 중지되어도 남은 항목은 다음 시작 때 같은 순서로 다시 처리됩니다.
local donationProcessingPath = donationQueuePath .. ".processing"
local donationQueueBusy = false
local lastQueueWaitMessage = nil

local function fileExists(path)
    local file = io.open(path, "r")
    if file == nil then
        return false
    end
    file:close()
    return true
end

local function moveQueueToProcessing()
    if fileExists(donationProcessingPath) then
        return donationProcessingPath
    end

    local queueFile = io.open(donationQueuePath, "r")
    if queueFile == nil then
        return nil
    end

    local firstLine = queueFile:read("*l")
    queueFile:close()
    if firstLine == nil then
        return nil
    end

    local moved, moveErr = os.rename(donationQueuePath, donationProcessingPath)
    if not moved then
        return nil, "후원 큐를 처리 파일로 옮기지 못했습니다: " .. tostring(moveErr)
    end

    local newQueueFile = io.open(donationQueuePath, "a")
    if newQueueFile == nil then
        return nil, "새 후원 큐 파일을 만들지 못했습니다."
    end
    newQueueFile:close()

    return donationProcessingPath
end

local function readFirstQueueLine(path)
    local file = io.open(path, "r")
    if file == nil then
        return nil, "처리 중인 후원 큐 파일을 열지 못했습니다."
    end

    local line = file:read("*l")
    file:close()
    return line
end

local function removeFirstQueueLine(path)
    local file = io.open(path, "r")
    if file == nil then
        return false, "처리 중인 후원 큐 파일을 열지 못했습니다."
    end

    file:read("*l")
    local remainingLines = {}
    for line in file:lines() do
        table.insert(remainingLines, line)
    end
    file:close()

    if #remainingLines == 0 then
        local removed, removeErr = os.remove(path)
        if not removed then
            return false, "처리 완료 파일을 지우지 못했습니다: " .. tostring(removeErr)
        end
        return true
    end

    local temporaryPath = path .. ".tmp"
    local temporaryFile = io.open(temporaryPath, "w")
    if temporaryFile == nil then
        return false, "후원 큐 임시 파일을 만들지 못했습니다."
    end

    for _, line in ipairs(remainingLines) do
        temporaryFile:write(line, "\n")
    end
    temporaryFile:close()

    local removed, removeErr = os.remove(path)
    if not removed then
        return false, "처리된 후원 값을 지우지 못했습니다: " .. tostring(removeErr)
    end

    local moved, moveErr = os.rename(temporaryPath, path)
    if not moved then
        return false, "남은 후원 값을 저장하지 못했습니다: " .. tostring(moveErr)
    end

    return true
end

local function parseDonationLine(line)
    local donationId, rawPlayerId, rawAmount = line:match("^([^\t]+)\t(-?%d+)\t(%d+)%s*$")
    local playerId = tonumber(rawPlayerId)
    local amount = tonumber(rawAmount)

    if donationId == nil or playerId == nil or amount == nil or amount <= 0 then
        return nil, "후원 큐 항목 형식이 올바르지 않습니다."
    end

    return {
        id = donationId,
        playerUid = { A = playerId, B = 0, C = 0, D = 0 },
        amount = amount,
    }
end

local function logQueueWait(message)
    if lastQueueWaitMessage ~= message then
        lastQueueWaitMessage = message
        log(message)
    end
end

local function processNextDonation()
    if donationQueueBusy then
        return
    end

    local processingPath, preparationErr = moveQueueToProcessing()
    if processingPath == nil then
        if preparationErr ~= nil then
            logQueueWait(preparationErr)
        end
        return
    end

    local line, readErr = readFirstQueueLine(processingPath)
    if line == nil then
        if readErr ~= nil then
            logQueueWait(readErr)
        else
            -- 비어 있는 처리 파일은 제거해야 새 큐를 이어서 처리할 수 있습니다.
            local removed, removeErr = os.remove(processingPath)
            if not removed then
                logQueueWait("빈 후원 처리 파일을 지우지 못했습니다: " .. tostring(removeErr))
            end
        end
        return
    end

    local donation, parseErr = parseDonationLine(line)
    if donation == nil then
        local removed, removeErr = removeFirstQueueLine(processingPath)
        if removed then
            log("후원 큐의 잘못된 항목을 삭제했습니다: " .. tostring(parseErr))
        else
            logQueueWait("잘못된 후원 큐 항목을 삭제하지 못했습니다: " .. tostring(removeErr))
        end
        return
    end

    donationQueueBusy = true
    local scheduledOk, scheduledErr = pcall(function()
        ExecuteInGameThread(function()
            local handledOk, handledErr = xpcall(function()
                -- 설정표에 없는 금액은 재시도하지 않고 큐에서 바로 제거합다
                -- 플레이어가 오프라인인 경우에도 이 판단을 먼저 수행해야 큐가 막히지 않는다
                if findDonationTier(donation.amount) == nil then
                    local removed, removeErr = removeFirstQueueLine(processingPath)
                    if not removed then
                        error("설정되지 않은 후원 금액을 큐에서 삭제하지 못했습니다. " .. tostring(removeErr))
                    end

                    lastQueueWaitMessage = nil
                    log("설정되지 않은 후원 금액 삭제: " .. donation.id
                        .. " / 금액 " .. tostring(donation.amount))
                    return
                end

                local playerState = findPlayerStateByUid(donation.playerUid)
                if playerState == nil then
                    logQueueWait("후원 큐 대기: 접속 중인 플레이어를 찾지 못했습니다 (UID.A="
                        .. tostring(donation.playerUid.A) .. ")")
                    return
                end

                local playerName = playerState.PlayerNamePrivate:ToString()
                local eventOk, tier, eventMessage = runDonationEvent(
                    donation.playerUid,
                    playerName,
                    donation.amount
                )
                if not eventOk then
                    logQueueWait("후원 큐 처리 대기: " .. donation.id .. " / " .. tostring(eventMessage))
                    return
                end

                local removed, removeErr = removeFirstQueueLine(processingPath)
                if not removed then
                    error("후원 처리 후 큐 값을 삭제하지 못했습니다: " .. tostring(removeErr))
                end

                lastQueueWaitMessage = nil
                local tierLabel = tier.label or (tostring(donation.amount) .. "원")
                log("후원 큐 처리 완료: " .. donation.id
                    .. " / " .. playerName
                    .. " / " .. tierLabel)
            end, debug.traceback)

            if not handledOk then
                logQueueWait("후원 큐 처리에 실패했습니다: " .. tostring(handledErr))
            end
            donationQueueBusy = false
        end)
    end)

    if not scheduledOk then
        donationQueueBusy = false
        logQueueWait("후원 큐 처리 예약에 실패했습니다: " .. tostring(scheduledErr))
    end
end

function writePlayerStatus()
    local statusFile = io.open(playerStatusPath, "w")
    if statusFile == nil then
        return
    end

    local players = PalPlayerControllers:getServerPlayers() or {}
    for _, player in pairs(players) do
        local playerState = player:GetPalPlayerState()
        if playerState ~= nil and playerState:IsValid() then
            local name = playerState.PlayerNamePrivate:ToString():gsub("[\t\r\n]", " ")
            statusFile:write(tostring(playerState.PlayerUId.A), "\t", name, "\n")
        end
    end
    statusFile:close()
end

function pollStreamerRegistrationResponses()
    local responseFile = io.open(streamerRegistrationResponsePath, "r")
    if responseFile == nil then
        return
    end

    if streamerRegistrationResponseOffset == nil then
        streamerRegistrationResponseOffset = responseFile:seek("end") or 0
        responseFile:close()
        log("CHZZK 등록 응답 감지를 시작했습니다: " .. streamerRegistrationResponsePath)
        return
    end

    local responseLength = responseFile:seek("end") or 0
    if streamerRegistrationResponseOffset > responseLength then
        streamerRegistrationResponseOffset = 0
    end
    responseFile:seek("set", streamerRegistrationResponseOffset)

    local pendingResponses = {}
    while true do
        local line = responseFile:read("*l")
        if line == nil then
            break
        end
        streamerRegistrationResponseOffset = responseFile:seek()

        local requestId, rawPlayerId, status, responseMessage = line:match("^([^\t]+)\t(-?%d+)\t([^\t]+)\t(.*)$")
        local playerId = tonumber(rawPlayerId)
        if requestId ~= nil and playerId ~= nil and status ~= nil then
            table.insert(pendingResponses, {
                playerId = playerId,
                status = status,
                message = responseMessage,
            })
        else
            log("형식이 올바르지 않은 CHZZK 등록 응답을 무시했습니다.")
        end
    end
    responseFile:close()

    if #pendingResponses > 0 then
        ExecuteInGameThread(function()
            for _, response in ipairs(pendingResponses) do
                local playerUid = { A = response.playerId, B = 0, C = 0, D = 0 }
                sendSystemToPlayer(playerUid, "[CHZZK] " .. response.message)
                log("CHZZK 응답 (" .. response.status .. ", UID.A=" .. tostring(response.playerId) .. "): " .. response.message)
            end
        end)
    end
end

LoopAsync(250, function()
    processNextDonation()

    local registrationOk, registrationErr = pcall(pollStreamerRegistrationResponses)
    if not registrationOk then
        log("CHZZK 응답 폴링에 실패했습니다: " .. tostring(registrationErr))
    end

    playerStatusPollCount = playerStatusPollCount + 1
    if playerStatusPollCount >= 20 then
        playerStatusPollCount = 0
        ExecuteInGameThread(function()
            local statusOk, statusErr = pcall(writePlayerStatus)
            if not statusOk then
                log("플레이어 상태 파일 작성에 실패했습니다: " .. tostring(statusErr))
            end
        end)
    end
    return false
end)
